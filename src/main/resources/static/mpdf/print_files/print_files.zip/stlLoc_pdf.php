<?php ob_start();
$html='
		<html>
		<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			<style>
					body {	
					font-family: sans-serif;
					font-size: 10pt; }
					
					p {	margin: 0pt; }

					table.gridtable { 
					font-family: verdana,arial,sans-serif;
					font-size:12px;
					
					border-width: 1px;
					border-color: #e3c5ca;
					border-collapse: collapse; }
					
					table.gridtable th {
					border-width: 1px;
					padding: 2px;
					border-style: solid;
					border-color: #e3c5ca;
					}

					table.gridtable td {
					border-width: 1px;
					padding: 2px;
					border-style: solid;
					border-color: #e3c5ca;
					 }
			</style>
		</head>
<body>

<!--mpdf
			<htmlpageheader name="myheader">	';
			
$html=$html.'	<div align="center" style="font-size:15px" >
<p align="center" ><img src="logo1.jpg" style="height:180px;width:100%"></p>
<hr><br>
					<table width="100%"><tr>
					<td width="30%"></td>
					<td align="center"><u> '.strtoupper("Stock Report-Location Wise(RM)").' </u></td>
					<td align="right">Date : '.date('d-m-Y').'</td>
					</tr></table>
				</div>
				</htmlpageheader>
			';
	
$html = $html.'	<htmlpagefooter name="myfooter" >

 					<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 2mm; ">
					Page {PAGENO} of {nb}
					</div>

				</htmlpagefooter>	
				
					<sethtmlpageheader name="myheader" value="on" show-this-page="1" />
					<sethtmlpagefooter name="myfooter" value="on" />
mpdf-->		';

include("mysql.connect.php");
date_default_timezone_set('Asia/Calcutta');	
$compId=$iType='0';
if(!empty($_GET['compId']))
$compId=$_GET['compId'];

if(!empty($_GET['iType']))
$iType=$_GET['iType'];

//echo "<Br>".$compId." : ".$iType." : ".$locId."<Br>";

$str="";


if($compId!='0' && $iType!='0')
{
	$str=$str." AND a.compId='$compId' AND a.iType='$iType' ";
}
else if($compId!='0' && $iType=='0')
{
	$str=$str." AND a.compId='$compId'";
}


else if($compId=='0' && $iType!='0')
{
	$str=$str." AND a.iType='$iType' ";
}




		$html=$html.'
					<table width="100%" class="gridtable" style="border:1px solid #e3c5ca" id="dataTable1"> 					
                    <thead>
                      <tr style="background-color:#b02923">
                      <th style="color:#fff">Focus Code</th>
                     
					  <th style="color:#fff">Sage Code</th>	
                      <th style="color:#fff;">Product</th>';
					  
					   $ql="SELECT loc_code,location_name FROM location_tbl WHERE sts!='2' AND iType='1' ORDER BY loc_code";	
					  $stl=$mysql->prepare($ql);
					  $stl->execute();
					  while($row1=$stl->fetch(PDO::FETCH_ASSOC))
					  {
                        $html=$html.' <th style="color:#fff">'.$row1['loc_code']." - ".$row1['location_name'].'</th>';
					  }
                    $html=$html.'<th style="color:#fff;">Total</th></tr>
                     
                              
                    </thead>';
$sql="SELECT a.iType,a.itemId,IF(a.iType='1',r.focus_code,f.focus_code) AS focus_code,IF(a.iType='1',r.sage_code,f.sage_code) AS sage_code,IF(a.iType='1',CONCAT(r.description,' - ',ru.uom),CONCAT(f.brand,' ',f.descc,' - ',fu.uom)) AS desp FROM stock_tbl AS a LEFT JOIN company_tbl AS c ON a.compId=c.ID LEFT JOIN location_tbl AS l ON a.locId=l.ID LEFT JOIN rm_master AS r ON a.itemId=r.rmId LEFT JOIN uom_tbl AS ru ON r.UOM=ru.ID LEFT JOIN fg_master AS f ON a.itemId=f.fgId LEFT JOIN uom_tbl AS fu ON f.uom=fu.ID WHERE a.sts!='2' AND IF(a.iType='1',r.sts!='2',f.sts!='2') ".$str." ORDER BY a.ID";
//$html=$html.$sql;
$statement = $mysql->prepare($sql);
$statement->setFetchMode(PDO::FETCH_OBJ);
$statement->execute();
$count=1;
$a=$b=$c=$d=$e=0;	
while($row=$statement->fetch())
{	
					 
$itemId=$row->itemId;
						
						
$html=$html.' 
<tr style="color:#000;font-weight:600;border:1px solid #e3c5ca;">
<td style="background-color:#96accd99;color:#000;border:1px solid #e3c5ca;">'.$row->focus_code.'</td>
<td style="background-color:#96accd99;color:#000;border:1px solid #e3c5ca;">'.$row->sage_code.'</td>
<td style="background-color:#96accd99;color:#000;border:1px solid #e3c5ca;">'.$row->desp.'</td>';

 $ql1="SELECT ID FROM location_tbl WHERE sts!='2' AND iType='1' ORDER BY loc_code";	
$stl1=$mysql->prepare($ql1);
$stl1->execute();
$tot=0;
while($row2=$stl1->fetch(PDO::FETCH_ASSOC))
{
	$locId=$row2['ID'];

	$qqq="SELECT SUM(a.stk_qty) AS stk FROM stock_tbl AS a LEFT JOIN company_tbl AS c ON a.compId=c.ID LEFT JOIN location_tbl AS l ON a.locId=l.ID LEFT JOIN rm_master AS r ON a.itemId=r.rmId LEFT JOIN uom_tbl AS ru ON r.UOM=ru.ID LEFT JOIN fg_master AS f ON a.itemId=f.fgId LEFT JOIN uom_tbl AS fu ON f.uom=fu.ID WHERE a.sts!='2' AND IF(a.iType='1',r.sts!='2',f.sts!='2') AND  a.iType='1' AND a.locId='$locId' AND a.itemId='$itemId' ORDER BY a.ID";
	$stl2=$mysql->prepare($qqq);
	$stl2->execute();
	$row11=$stl2->fetch(PDO::FETCH_ASSOC);
	$stk=0;
	if(!empty($row11['stk']))
	{
		$stk=$row11['stk'];
		$tot=$tot+$stk;
	}	
	$html=$html.'<td style="background-color:#96accd99;color:#000;border:1px solid #e3c5ca;">'.$stk.'</td>';
}
$html=$html.'<td style="background-color:#edd18361;color:#000">'.$tot.'</td>';
$a=$a+$tot;
$html=$html.'</tr>';  				 
}
$html=$html.'<tfoot>
<tr style="background-color:#b02923">
<th style="color:#fff;"></th>
<th style="color:#fff"></th>
<th style="color:#fff;"></th>';
$ql="SELECT loc_code,location_name FROM location_tbl WHERE sts!='2' AND iType='1' ORDER BY loc_code";	
$stl=$mysql->prepare($ql);
$stl->execute();
$ct=$stl->rowCount();
$k=1;
while($row1=$stl->fetch(PDO::FETCH_ASSOC))
{
	if($k==$ct)
	{
	$html=$html. '<th style="color:#fff">Total</th> '; 
	}
	else
	{
	$html=$html. '<th style="color:#fff"></th> ';  
	}
	$k++;  
}
$html=$html.'<th style="color:#fff;">'.$a.'</th>
</tr>
</tfoot>';
$html=$html.'</table>';
	
$html = $html.'</body>';


$html = $html.'</html>';
$mysql=null;
//echo $html."<Br>";
define('_MPDF_PATH','../');
include("../mpdf.php");
//include("/var/www/vhosts/darshanuniforms.com/pr.darshanuniforms.com/mpdf/mpdf.php");

$mpdf=new mPDF('c','A4','','',5,5,65,20,5,5);

//('defalt','A4','font-size','font-family','margin-left','margin-right','margin-top','margin-botm','mar-head','mar-foor','L/P') 
$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("Stock Report - Location Wise(RM)");
$mpdf->SetAuthor("");
$mpdf->SetWatermarkText("");
$mpdf->showWatermarkText = false;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');
$mdf->setAutoBottonMargin = 'stretch';
$mdf->setAutoTopMargin = 'stretch';

$mpdf->WriteHTML($html);
ob_clean();
$mpdf->Output(); 
exit;
?>