<?php ob_start();
$html='
		<html>
		<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			<style>
					body {	
					font-family: sans-serif;
					font-size: 10pt; }
					
					p {	margin: 0pt; }

					table.gridtable { 
					font-family: verdana,arial,sans-serif;
					font-size:12px;
					color:#333333;
					border-width: 1px;
					border-color: #cdcdcd;
					border-collapse: collapse; }
					
					table.gridtable th {
					border-width: 1px;
					padding: 2px;
					border-style: solid;
					border-color: #cdcdcd;
					}

					table.gridtable td {
					border-width: 1px;
					padding: 2px;
					border-style: solid;
					border-color: #cdcdcd;
					 }
			</style>
		</head>
<body>

<!--mpdf
			<htmlpageheader name="myheader">	';
			
$html=$html.'	<div align="center" style="font-size:15px" >
<p align="center" ><img src="logo1.jpg" style="height:180px;width:100%"></p>
<hr><br>
					<table width="100%"><tr>
					<td width="30%"></td>
					<td align="center"><u> '.strtoupper("Out Of Stock Report").' </u></td>
					<td align="right">Date : '.date('d-m-Y').'</td>
					</tr></table>
				</div>
				</htmlpageheader>
			';
	
$html = $html.'	<htmlpagefooter name="myfooter" >

 					<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 2mm; ">
					Page {PAGENO} of {nb}
					</div>

				</htmlpagefooter>	
				
					<sethtmlpageheader name="myheader" value="on" show-this-page="1" />
					<sethtmlpagefooter name="myfooter" value="on" />
mpdf-->		';

include("mysql.connect.php");
$compId=$locId=$iType='0';
if(!empty($_GET['compId']))
$compId=$_GET['compId'];

if(!empty($_GET['locId']))
$locId=$_GET['locId'];

if(!empty($_GET['iType']))
$iType=$_GET['iType'];

//echo "<Br>".$compId." : ".$iType." : ".$locId."<Br>";

$str="";

if($compId!='0' && $iType!='0' && $locId!='0')
{
	$str=$str." AND a.compId='$compId' AND a.iType='$iType' AND a.locId='$locId' ";
}
if($compId!='0' && $iType!='0' && $locId=='0')
{
	$str=$str." AND a.compId='$compId' AND a.iType='$iType' ";
}
else if($compId!='0' && $iType=='0' && $locId!='0')
{
	$str=$str." AND a.compId='$compId' AND a.locId='$locId' ";
}
else if($compId!='0' && $iType=='0' && $locId=='0')
{
	$str=$str." AND a.compId='$compId' ";
}
else if($compId=='0' && $iType!='0' && $locId!='0')
{
	$str=$str." a.locId='$locId' AND a.iType='$iType' ";
}
else if($compId=='0' && $iType=='0' && $locId!='0')
{
	$str=$str." a.locId='$locId' ";
}
else if($compId=='0' && $iType!='0' && $locId=='0')
{
	$str=$str." a.iType='$iType' ";
}		
										
$sql="SELECT a.iType,IF(a.iType='1',r.focus_code,f.focus_code) AS focus_code,IF(a.iType='1',r.sage_code,f.sage_code) AS sage_code,IF(a.iType='1',CONCAT(rg.category_nm,' ',r.description,' - ',ru.uom),CONCAT(fgg.category_nm,' ',f.brand,' ',f.descc,' - ',fu.uom)) AS desp,'0' AS openstk,a.in_qty AS IN_Qty,a.out_qty AS OUT_Qty,a.lock_qty AS Lock_Qty,a.stk_qty AS Closestk,IF(a.iType='1',r.rackNo,f.rackNo) AS rack,IF(a.iType='1',r.reorder_level_qty,f.reorder_level_qty) rorder,CONCAT(l.loc_code,' - ',l.location_name) AS locNm,IF(a.iType='1','RAW MATERIAL','FINISHED GOODS') AS iTypeNm FROM stock_tbl AS a LEFT JOIN company_tbl AS c ON a.compId=c.ID LEFT JOIN location_tbl AS l ON a.locId=l.ID LEFT JOIN rm_master AS r ON a.itemId=r.rmId LEFT JOIN uom_tbl AS ru ON r.UOM=ru.ID LEFT JOIN fg_master AS f ON a.itemId=f.fgId LEFT JOIN uom_tbl AS fu ON f.uom=fu.ID LEFT JOIN category_master AS rg ON r.catId=rg.catId LEFT JOIN category_master AS fgg ON f.category_id=fgg.catId WHERE a.sts!='2' AND IF(a.iType='1',r.sts!='2',f.sts!='2') AND a.stk_qty='0' ".$str." ORDER BY a.ID";
//echo $sql."<Br>";
//$html=$html.$sql;
$statement = $mysql->prepare($sql);
$statement->setFetchMode(PDO::FETCH_OBJ);
$statement->execute();
$count=1;

$html=$html.'
<table width="100%" class="gridtable" id="dataTable1"> 					
<thead>
<tr style="background-color:#b02923">
<th style="color:#fff;">Location</th>
<th style="color:#fff;">Focus Code</th>
<th style="color:#fff">Sage Code</th>
<th style="color:#fff;">Product</th>
<!--<th style="color:#fff">Opening Stock</th>-->
<th style="color:#fff;">IN</th>
<th style="color:#fff">OUT</th>
<th style="color:#fff;">Lock Qty</th>
<th style="color:#fff;"><!--Closing-->Avail. Stock</th>
<th style="color:#fff">Re - Order Level</th>
<th style="color:#fff">Re - Order Req.</th>
<th style="color:#fff">Rack No.</th>
</thead>
<tbody>"';
$a=$b=$c=$d=$e=0;	
while($row=$statement->fetch(PDO::FETCH_ASSOC))
{
    $a=$a+$row['openstk'];
			$b=$b+$row['IN_Qty'];
			$c=$c+$row['OUT_Qty'];
			$d=$d+$row['Lock_Qty'];
			$e=$e+$row['Closestk'];
	
	

    if($row['iType']=='1')
    {        
      $html=$html.'<tr style="color:#000;font-weight:600;">';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['locNm'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['focus_code'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['sage_code'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['desp'].'</td>';
      /*$html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['openstk'].'</td>';*/
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['IN_Qty'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['OUT_Qty'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['Lock_Qty'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['Closestk'].'</td>';
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['rorder'].'</td>';
	  if($row['Closestk']<$row['rorder'])
	  {
		  $html=$html. '<td style="background-color:#96accd99;color:#F00;font-weight:bold;">Yes</td>';
	  }
	  else
	  {
		  $html=$html. '<td style="background-color:#96accd99;color:#000;font-weight:bold;">No</td>';
	  }
		 
      $html=$html. '<td style="background-color:#96accd99;color:#000">'.$row['rack'].'</td>';
      $html=$html. '</tr>';	  
    }
    else
    {            
      $html=$html.'<tr style="color:#000;font-weight:600;">';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['locNm'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['focus_code'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['sage_code'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['desp'].'</td>';
      /*$html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['openstk'].'</td>';*/
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['IN_Qty'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['OUT_Qty'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['Lock_Qty'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['Closestk'].'</td>';
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['rorder'].'</td>';      
      if($row['Closestk']<$row['rorder'])
	  {
		  $html=$html. '<td style="background-color:#edd18361;color:#F00;font-weight:bold;">Yes</td>';
	  }
	  else
	  {
		  $html=$html. '<td style="background-color:#edd18361;color:#000;font-weight:bold;">No</td>';
	  }		
      $html=$html. '<td style="background-color:#edd18361;color:#000">'.$row['rack'].'</td>';
      $html=$html. '</tr>'; 
    }				  
    $count++;
}
$html=$html."</tbody>";
$html=$html.'<tfoot>
<tr style="background-color:#b02923">
<th style="color:#fff"></th>
<th style="color:#fff;"></th>
<th style="color:#fff"></th>
<th style="color:#fff;">Total</th>
<th style="color:#fff">'.$b.'</th>
<th style="color:#fff;">'.$c.'</th>
<th style="color:#fff">'.$d.'</th>
<th style="color:#fff;">'.$e.'</th>
<th style="color:#fff;"></th>
<th style="color:#fff"></th>
<th style="color:#fff"></th>
<!--<th style="color:#fff"></th>
<th style="color:#fff"></th>-->
</tr>
</tfoot>';
$html=$html.'</table>';
	
$html = $html.'</body>';


$html = $html.'</html>';
$mysql=null;
//echo $html."<Br>";
define('_MPDF_PATH','../');
include("../mpdf.php");
//include("/var/www/vhosts/darshanuniforms.com/pr.darshanuniforms.com/mpdf/mpdf.php");

$mpdf=new mPDF('c','A4','','',5,5,65,20,5,5);

//('defalt','A4','font-size','font-family','margin-left','margin-right','margin-top','margin-botm','mar-head','mar-foor','L/P') 
$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("Out Of Stock Report");
$mpdf->SetAuthor("");
$mpdf->SetWatermarkText("");
$mpdf->showWatermarkText = false;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');
$mdf->setAutoBottonMargin = 'stretch';
$mdf->setAutoTopMargin = 'stretch';

$mpdf->WriteHTML($html);
ob_clean();
$mpdf->Output(); 
exit;

?>