<?php ob_start();
$html='
		<html>
		<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
			<style>
					body {	
					font-family: sans-serif;
					font-size: 10pt; }
					
					p {	margin: 0pt; }

					table.gridtable { 
					font-family: verdana,arial,sans-serif;
					font-size:12px;
					
					border-width: 1px;
					border-color: #e3c5ca;
					border-collapse: collapse; }
					
					table.gridtable th {
					border-width: 1px;
					padding: 2px;
					border-style: solid;
					border-color: #e3c5ca;
					}

					table.gridtable td {
					border-width: 1px;
					padding: 2px;
					border-style: solid;
					border-color: #e3c5ca;
					 }
			</style>
		</head>
<body>

<!--mpdf
			<htmlpageheader name="myheader">	';
			
$html=$html.'	<div align="center" style="font-size:15px" >
<p align="center" ><img src="logo1.jpg" style="height:180px;width:100%"></p>
<hr><br>
					<table width="100%"><tr>
					<td width="30%"></td>
					<td align="center"><u> '.strtoupper("Product Expiry Report").' </u></td>
					<td align="right">Date : '.date('d-m-Y').'</td>
					</tr></table>
				</div>
				</htmlpageheader>
			';
	
$html = $html.'	<htmlpagefooter name="myfooter" >

 					<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 2mm; ">
					Page {PAGENO} of {nb}
					</div>

				</htmlpagefooter>	
				
					<sethtmlpageheader name="myheader" value="on" show-this-page="1" />
					<sethtmlpagefooter name="myfooter" value="on" />
mpdf-->		';

include("mysql.connect.php");
date_default_timezone_set('Asia/Calcutta');	
$compId=$locId=$iType='0';
if(!empty($_GET['compId']))
$compId=$_GET['compId'];

if(!empty($_GET['locId']))
$locId=$_GET['locId'];

if(!empty($_GET['iType']))
$iType=$_GET['iType'];

//echo "<Br>".$compId." : ".$iType." : ".$locId."<Br>";

$str="";

if($compId!='0' && $iType!='0' && $locId!='0')
{
	$str=$str." AND a.compId='$compId' AND a.iType='$iType' AND a.locId='$locId' ";
}
if($compId!='0' && $iType!='0' && $locId=='0')
{
	$str=$str." AND a.compId='$compId' AND a.iType='$iType' ";
}
else if($compId!='0' && $iType=='0' && $locId!='0')
{
	$str=$str." AND a.compId='$compId' AND a.locId='$locId' ";
}
else if($compId!='0' && $iType=='0' && $locId=='0')
{
	$str=$str." AND a.compId='$compId' ";
}
else if($compId=='0' && $iType!='0' && $locId!='0')
{
	$str=$str." AND a.locId='$locId' AND a.iType='$iType' ";
}
else if($compId=='0' && $iType=='0' && $locId!='0')
{
	$str=$str." AND a.locId='$locId' ";
}
else if($compId=='0' && $iType!='0' && $locId=='0')
{
	$str=$str." AND a.iType='$iType' ";
}

$sql="SELECT a.ID,a.docNo,a.dt,a.compId,CONCAT(b.company_code,' - ',b.company_name) AS compNm,
 a.locId,CONCAT(c.loc_code,' - ', c.location_name) AS loc,a.iType,IF(a.iType='1','RAW MATERIAL','FINISHED GOODS') AS iTypeNm,a.itemId,
IF(a.iType='1',d.focus_code,f.focus_code) AS fc,
IF(a.iType='1',d.sage_code,f.sage_code) AS sg,
IF(a.iType='1',d.description,CONCAT(g.category_nm,' ',f.brand,' ',f.descc)) AS itemNm,
IF(a.iType='1',u.uom,u2.uom) AS uom,
IF(a.stk_qty='0',a.openstk,a.stk_qty) AS qty,a.expdt,a.uid,TIMESTAMPDIFF(MONTH, CURRENT_DATE(),a.expdt) AS mnt,a.batchNo
FROM stock_tbl_2 AS a 
 LEFT JOIN company_tbl AS b ON a.compId=b.ID 
 LEFT JOIN location_tbl AS c ON a.locId=c.ID 
 LEFT JOIN rm_master AS d ON a.itemId=d.rmId
 LEFT JOIN uom_tbl AS u ON d.UOM=u.ID 
 LEFT JOIN fg_master AS f ON a.itemId=f.fgId 
 LEFT JOIN uom_tbl AS u2 ON f.uom=u2.ID 
 LEFT JOIN category_master AS g ON f.category_id=g.catId 
 WHERE a.sts!='2' AND b.sts!='2' AND c.sts!='2' AND a.out_qty='0' AND IF(a.iType='1',d.sts!='2',f.sts!='2') ".$str." ORDER BY a.dt";
			$statement = $mysql->prepare($sql);
			$statement->setFetchMode(PDO::FETCH_OBJ);
			$statement->execute();
			$count=1;

if ($row=($sql))
	{
		$html=$html.'
					<table width="100%" class="gridtable" style="border:1px solid #e3c5ca" id="dataTable1"> 					
                    <thead>
                      <tr style="background-color:#b02923">
                      <th style="color:#fff">Date</th>
                     
					  <th style="color:#fff">Location</th>	
                      <th style="color:#fff;">Focus Code</th>
                      <th style="color:#fff">Sage Code</th>
                      <th style="color:#fff">Product</th>
                      <th style="color:#fff">Batch No</th>
                      <th style="color:#fff">Qty</th>
                      <th style="color:#fff">Prod. Exp. Date</th>
                    </tr>
                     
                    </tr>                
                    </thead>

					"';
					 $crd=date('Y-m');
					while($row=$statement->fetch())
					{	
					 
					 $expdt=date('Y-m',strtotime($row->expdt));
					  //echo "Current : ".$crd."|| Expdt : ".$expdt."<Br>";
					  $date_diff = abs(strtotime($crd) - strtotime($expdt));
					  $years = floor($date_diff / (365*60*60*24));
					  if($crd>$expdt)
					  {
					  	$mnt = "-".floor(($date_diff - $years * 365*60*60*24) / (30*60*60*24));
					  }
					  else
					  {
					  	$mnt = floor(($date_diff - $years * 365*60*60*24) / (30*60*60*24));
					  }								
						
						if($mnt <=1 && $mnt<2 && $years==0)
						{
						  $html=$html.' 
						 <tr style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">
						  <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->dt)).'</td>
						 <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.$row->loc.'</td>
						  <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.$row->fc.'</td>
						 <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.$row->sg.'</td>
						  
						 <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.$row->itemNm.' - '.$row->uom.'</td>
						 <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.$row->batchNo.'</td>
						 <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.$row->qty.'</td>
						  <td style="color:#F00;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->expdt)).'</td>
						 </tr>';  
					  }
					  else if($mnt >=2 && $mnt<3 && $years==0)
                     {
						  $html=$html.' 
						 <tr style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">
						  <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->dt)).'</td>
						 <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.$row->loc.'</td>
						  <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.$row->fc.'</td>
						 <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.$row->sg.'</td>
						  
						 <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.$row->itemNm.' - '.$row->uom.'</td>
						 <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.$row->batchNo.'</td>
						 <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.$row->qty.'</td>
						  <td style="color:orange;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->expdt)).'</td>
						 </tr>';  
					 }
					 else if($mnt=='3' && $years==0)
                    {
						$html=$html.' 
						 <tr style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">
						  <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->dt)).'</td>
						 <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.$row->loc.'</td>
						  <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.$row->fc.'</td>
						 <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.$row->sg.'</td>
						  
						 <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.$row->itemNm.' - '.$row->uom.'</td>
						 <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.$row->batchNo.'</td>
						 <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.$row->qty.'</td>
						  <td style="color:#0472c9;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->expdt)).'</td>
						 </tr>';  
					}
					else
                   {
					   $html=$html.' 
						 <tr style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">
						  <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->dt)).'</td>
						 <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.$row->loc.'</td>
						  <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.$row->fc.'</td>
						 <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.$row->sg.'</td>
						  
						 <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.$row->itemNm.' - '.$row->uom.'</td>
						 <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.$row->batchNo.'</td>
						 <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.$row->qty.'</td>
						  <td style="background-color:#FFF;color:#000;font-weight:bold;border:1px solid #e3c5ca;">'.date('d-m-Y',strtotime($row->expdt)).'</td>
						 </tr>';  
				   }
					}
					
					
		$html=$html.'</table>';
	}
	
$html = $html.'</body>';


$html = $html.'</html>';
$mysql=null;

define('_MPDF_PATH','../');
include("../mpdf.php");
//include("/var/www/vhosts/darshanuniforms.com/pr.darshanuniforms.com/mpdf/mpdf.php");

$mpdf=new mPDF('c','A4','','',5,5,65,20,5,5);

//('defalt','A4','font-size','font-family','margin-left','margin-right','margin-top','margin-botm','mar-head','mar-foor','L/P') 
$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("Product Expiry Date Register");
$mpdf->SetAuthor("");
$mpdf->SetWatermarkText("");
$mpdf->showWatermarkText = false;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');
$mdf->setAutoBottonMargin = 'stretch';
$mdf->setAutoTopMargin = 'stretch';

$mpdf->WriteHTML($html);
ob_clean();
$mpdf->Output(); 
exit;
?>